export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAVSt8mXi614nJnRQtNCJ_PbbZrQmPhjmA",
  authDomain: "senior-1dd55.firebaseapp.com",
  projectId: "senior-1dd55",
  storageBucket: "senior-1dd55.appspot.com",
  messagingSenderId: "792135877003",
  appId: "1:792135877003:web:a99a47673db25ac83def8e",
  measurementId: "G-5VDY48E5TD"
   }
};

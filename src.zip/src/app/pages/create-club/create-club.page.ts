import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController, ModalController, NavController } from '@ionic/angular';
import { authenticationService, userData } from 'src/app/services/authentication.service';
import firebase from 'firebase/compat/app';
import { AngularFirestore, DocumentReference } from '@angular/fire/compat/firestore';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { finalize } from 'rxjs/operators';
import { TheaterPage } from '../clubs/theater/theater.page';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-create-club',
  templateUrl: './create-club.page.html',
  styleUrls: ['./create-club.page.scss'],
})
export class CreateClubPage implements OnInit {
  public page: string = 'create-club';
  signInForm: FormGroup;
  va: any;
  public leaders:userData[]=[];
  submitted = false;
  submitted2 = false;
  submitted3 = false;
  submitted4 = false;
  submitted5 = false;
  submitted6 = false;
  name = "";
  pass = "";
  public reloaded:boolean=true;
  public createdBy: string = '';
  public userId: any;
  public club: string = '';
  public sample1:any;
public file:any;
  constructor(
    public alertCtrl: AlertController,
    public formbuilder: FormBuilder,
    public nav: NavController,
    public fire: authenticationService,
    private modalController: ModalController,
    public alert: AlertController,
    private loading: LoadingController,
    public firestore: AngularFirestore,
    private storage: AngularFireStorage,
    public router:Router,
  )  {
    this.signInForm = formbuilder.group({
      name: [null, Validators.compose([Validators.required, Validators.minLength(6)])],
      leader: [null, Validators.compose([Validators.required,])],
      info: [null, Validators.compose([Validators.required, Validators.minLength(10)])],
    });
  }


  subPassword() {
    this.submitted2 = true;
  }



  subType() {
    this.submitted4 = true;
  }




  get f() {
    return this.signInForm.controls;
  }

  async ngOnInit() {
    this.fire.checkUserAuthentication(this.page);
    const sessionValue = sessionStorage.getItem('currentUser');
    if (sessionValue) {
      const userId = JSON.parse(sessionValue);
      this.userId = userId;
    }

    this.firestore.collection('users').doc(this.userId).get().subscribe(
      async (userDoc) => {
        if (userDoc.exists) {
          const x = userDoc.data() as userData;
          if (x.type === 'admin') {
            console.log(`Welcome admin`);          } else {
            this.nav.navigateForward('tabs/tab1');
              this.showAlertUser();
          }
        }
      }
    );
    this.firestore.collection('users', ref => ref.where('type', '==', 'leader'))
    .valueChanges()
    .subscribe((users: unknown[]) => {
      const typedUsers = users as userData[]; // Cast the 'users' array to 'userData[]'
      console.log(typedUsers);
      this.leaders.push(...typedUsers);
      console.log(this.leaders);
    });
  }
  async showAlertUser() {
    return new Promise<void>(async (resolve) => {
      const alert = await this.alertCtrl.create({
        header: 'Sorry, Only Admins Can Access This Page',
        message: '',
        buttons: [
          {
            text: 'OK',
            handler: () => {
              resolve(); // Resolve the promise when the OK button is clicked
            },
          },
        ],
      });
  
      await alert.present();
    });
  }

  subName() {
    this.submitted = true;
  }



  subLocation() {
    this.submitted3 = true;
  }

 
  subInfo(){
    this.submitted6= true;
  }

 
 
  addEvent() {
    if (this.signInForm.valid) {
      const formValue = this.signInForm.value;
      this.name = formValue.name;
      
      this.firestore.collection(formValue.name).get().toPromise().then((querySnapshot) => {
        if (querySnapshot && querySnapshot.size > 0) {
          // Collection with the same name already exists, show alert
          this.showCollectionExistsAlert();
        } else {
          // Collection does not exist, proceed with creation
          this.showAlert().then((alert) => {
            if (alert.role === 'confirm') {
              this.presentLoading().then(() => {
                // Check 'users' collection for club_name field
                const usersRef = this.firestore.collection('users');
                usersRef
                  .ref.where('name', '==', formValue.leader)
                  .get()
                  .then((querySnapshot) => {
                    if (!querySnapshot.empty) {
                      querySnapshot.forEach((doc) => {
                        const userRef = doc.ref;
                        const userData = doc.data() as userData;
  
                        const clubName = userData.club_name;
                        if (clubName === 'notLeader') {
                          // Update club_name for the user
                          this.firestore.collection(this.name).add({}).then(()=>{
                            userRef.update({ club_name: this.name,intro:formValue.info }).then(() => {
                              this.dismissLoading();
                              this.showSuccessAlert();
                            }).catch(() => {
                              this.dismissLoading();
                              this.showErrorAlert();
                            });
                          })
                        } else {
                          this.dismissLoading();
                          // Leader is already assigned to a different club, show alert
                          this.showLeaderAssignedAlert();
                        }
                      });
                    }
                  })
                  .catch(() => {
                    this.dismissLoading();
                    this.showErrorAlert();
                  });
              });
            }
          });
        }
      });
    }
  }
  
  showCollectionExistsAlert() {
    this.alert.create({
      header: 'a club with the same name already exists',
      message: 'Please choose a different name for the club.',
      buttons: ['OK']
    }).then(alert => alert.present());
  }
  showLeaderAssignedAlert() {
    this.alert.create({
      header: 'this leader is already assigned to a different club',
      message: 'Please choose a different leader for the club.',
      buttons: ['OK']
    }).then(alert => alert.present());
  }
  
  showSuccessAlert() {
    this.alert.create({
      header: 'club added successfully',
      message: 'The club has been added successfully.',
      buttons: ['OK']
    }).then(alert => alert.present());
  }
  
  showErrorAlert() {
    this.alert.create({
      header: 'Error',
      message: 'An error occurred while adding the club.',
      buttons: ['OK']
    }).then(alert => alert.present());
  }
  async showAlert2() {
    const alert = await this.alert.create({
      header: 'club Added Successfully!',
      message: '',
      buttons: []
    });

    await alert.present();

    return new Promise<void>((resolve) => {
      setTimeout(() => {
        resolve();
      }, 200);
    });
  }

  dismissAlert() {
    this.alert.dismiss();
  }

  async showAlert() {
    const alert = await this.alert.create({
      header: `Are you sure you want to create the club "${this.name}"?`,
      message: '',
      buttons: [
        {
          text: 'Yes',
          role: 'confirm'
        },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    });

    await alert.present();

    return alert.onDidDismiss();
  }

  async presentLoading() {
    const loading = await this.loading.create({
      message: 'adding new club...',
      spinner: 'lines', // Choose the type of spinner you want
      translucent: true,
      backdropDismiss: false, // Prevent dismissing the loading by tapping outside
      keyboardClose: false // Prevent dismissing the loading by pressing the keyboard
    });
    await loading.present();
  }

  dismissLoading() {
    this.loading.dismiss();
  }
  close() {
    this.modalController.dismiss({
      'dismissed': true,
      'reloaded': true // Set the 'reloaded' value as true
    }).then(() =>{
      const r = this.reloaded;
      this.router.navigate(['tabs/tab1'],).then(()=>{
        location.reload();
      })
    }
    );
  }

}
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreatedEventsPageRoutingModule } from './created-events-routing.module';

import { CreatedEventsPage } from './created-events.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreatedEventsPageRoutingModule
  ],
  declarations: [CreatedEventsPage]
})
export class CreatedEventsPageModule {}

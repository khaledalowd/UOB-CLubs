import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController, ModalController, NavController } from '@ionic/angular';
import { AngularFirestore,DocumentReference, AngularFirestoreCollection } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import {QuerySnapshot, DocumentData } from '@angular/fire/firestore';
import firebase from 'firebase/compat/app';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { firstValueFrom } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { authenticationService, userData } from 'src/app/services/authentication.service';
import { RetrieveClubEventsService } from 'src/app/services/retrieve-club-events.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.page.html',
  styleUrls: ['./logout.page.scss'],
})
export class LogoutPage implements OnInit {
  public userId:any;
  public page:string='logout';
  public leader:boolean=false;
  constructor(public router:Router,
    private loading: LoadingController,
    private retrieveClubEventsService: RetrieveClubEventsService,
    public auth:authenticationService,
  public route:ActivatedRoute,
  private afData: AngularFirestore,
  private modalController: ModalController,
  public alert: AlertController,
  private storage: AngularFireStorage,
  public firestore:AngularFirestore,
  public formbuilder: FormBuilder,
  
  
  ) {}

  async ngOnInit(){
    await this.auth.checkUserAuthentication(this.page);
    const sessionValue = sessionStorage.getItem('currentUser');
    if (sessionValue) {
      const userId = JSON.parse(sessionValue);
    }
  // Remove the 'currentUser' item from session storage
await this.logout();
this.router.navigateByUrl('tabs/tab1').then(()=>{
  location.reload();
})

}
 logout(){
// Remove the 'currentUser' item from session storage
sessionStorage.removeItem('currentUser');
}

}

import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { authenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.page.html',
  styleUrls: ['./forget-password.page.scss'],
})
export class ForgetPasswordPage implements OnInit {
  signInForm: FormGroup;
  submitted = false;
  loading: any;

  constructor(
    public alertCtrl: AlertController,
    public formbuilder: FormBuilder,
    public nav: NavController,
    public fire: AngularFireAuth,
    private loadingController: LoadingController
  ) {
    this.signInForm = formbuilder.group({
      email: [null, Validators.compose([Validators.required, Validators.email])],
    });
  }

  ngOnInit() {}

  subEmail() {
    this.submitted = true;
  }

  get f() {
    return this.signInForm.controls;
  }

  async resetPass() {
    if (this.signInForm.valid) {
      const email = this.signInForm.get('email')?.value;
  
      if (email) {
        try {
          this.loading = await this.loadingController.create({
            message: 'Sending reset email...',
          });
          await this.loading.present();
  
          await this.fire.sendPasswordResetEmail(email);
  
          await this.loading.dismiss();
  
          const alert = await this.alertCtrl.create({
            header: 'Reset Password',
            message: 'A password reset email has been sent to your email address.',
            buttons: ['OK'],
          });
          await alert.present();
          this.signInForm.reset();
          this.nav.navigateBack('/login');
        } catch (error:any) {
          await this.loading.dismiss();
          console.error('Error sending password reset email:', error);
  
          let errorMessage = 'An error occurred while sending the password reset email.';
          if (error.code) {
            errorMessage = this.getErrorMessage(error.code);
          }
  
          const alert = await this.alertCtrl.create({
            header: 'Error',
            message: errorMessage,
            buttons: ['OK'],
          });
          await alert.present();
        }
      }
    }
  }
  
  getErrorMessage(errorCode: string): string {
    switch (errorCode) {
      case 'auth/invalid-email':
        return 'The email address is not valid.';
      case 'auth/user-not-found':
        return 'The email address is not registered.';
      case 'auth/too-many-requests':
        return 'Too many requests. Try again later.';
      default:
        return 'An error occurred. Please try again later.';
    }
  }
}